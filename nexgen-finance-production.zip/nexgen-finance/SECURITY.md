# Security Policy — NexGen Finance

## Supported Versions

| Version | Supported |
|---------|-----------|
| 2.x     | ✅ Yes |
| 1.x     | ❌ End of life |

## Reporting a Vulnerability

**Do not open a public GitHub issue for security vulnerabilities.**

Email: security@corverxis.com  
PGP:   Available on request  
Response SLA: 48 hours for critical, 7 days for moderate

## Security Architecture

| Control | Implementation |
|---|---|
| Encryption at rest | AES-256-GCM (reports, user inputs) |
| Encryption in transit | TLS 1.3 enforced (Render.com) |
| Authentication | OAuth2 (Google/GitHub/Microsoft) + JWT |
| Token storage | HttpOnly, Secure, SameSite cookies |
| API key storage | bcrypt hashed, prefix only exposed |
| Audit trail | Tamper-evident SHA-256 chained log |
| Rate limiting | Per-user and per-IP, tiered by endpoint |
| Input validation | express-validator on all inputs |
| CSP | Strict Content-Security-Policy header |
| HSTS | 1-year max-age with preload (production) |
| Session hygiene | Automatic expiry purge, revocation on logout |
| Secrets | Environment variables, never committed |

## Compliance

- **SOC 2 Type II** — CC6, CC7, CC9 controls implemented  
- **SEC Rule 17a-4** — 7-year financial record retention  
- **GDPR** — Articles 5, 6, 7, 17, 20, 25, 32  
- **CCPA** — §1798.100–199 data subject rights  
- **OWASP Top 10** — Mitigations for all categories  
